from django.urls import path
from . import views


urlpatterns = [

    # ---------------- USER AUTH ---------------- #
    path("", views.home, name="home"),

    path("register/", views.registration_page, name="register"),

    path("login/", views.login_user, name="login"),

    path("reset/", views.resetpage, name="reset"),

    path("reset-password/", views.reset_password, name="reset_password"),

    
    # ---------------- SELLERS ---------------- #

    path("seller/", views.sellerpage, name="seller"),

    path("create-store/", views.create_store, name="create_store"),

    path("store/<int:store_id>/", views.view_store, name="store_detail"),

    path("seller-products/", views.view_products, name="view_products"),

    path("delete-store/<int:store_id>/", views.remove_store, name="remove_store"),

    path("edit-store/<int:store_id>/", views.edit_store, name="edit_store"),


    # ---------------- BUYERS ---------------- #

    path("buyer/", views.buyerpage, name="buyer"),

    path("products/", views.buyer_products, name="product_list"),

    path("cart/", views.view_cart, name="view_cart"),

    path("add-to-cart/<int:product_id>/", views.add_to_cart, name="add_to_cart"),

    path("checkout/", views.checkoutpage, name="checkoutpage"),

    path("checkout-process/", views.checkout, name="checkout"),


    # ---------------- REVIEWS ---------------- #

    path("review/<int:product_id>/", views.leave_review, name="leave_review"),

]