from django.test import TestCase

from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth.models import User  
from django.contrib.auth import login,logout,authenticate
from django.http import HttpResponseRedirect,HttpResponseForbidden
from django.urls import reverse 
from django.contrib.auth import update_session_auth_hash
from .models import Store,Order,Profile,Product,Review
from django.contrib.auth.decorators import login_required
from django.core.mail import EmailMessage
from rest_framework import viewsets
from .serializers import StoreSerializer, ProductSerializer, ReviewSerializer
from .functions.twitter import Tweet



    #------------------------------------------------------------------User registration and login------------------------------------------------------------------#


                                                         #####------------User registrations -------------#####
                                                      
def registration_page(request):
    """
    Handle new user registration.

    Creates a new user and associated profile.

    Parameters
    ----------
    request : HttpRequest
        Incoming HTTP request.

    Returns
    -------
    HttpResponse
        Registration page with success message or form.
    """

    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        email = request.POST.get('email')
        user_type = request.POST.get('user_type')

        # Create user
        user = User.objects.create_user(
            username=username,
            password=password,
            email=email
        )

        # Create profile
        Profile.objects.create(
            user=user,
            user_type=user_type
        )

        return render(request, "registration.html", {
            "success_registered": "Registration successful, please login"
        })

    return render(request, "registration.html")

                                                        #####------------User Login -------------#####
def login_user(request):
    """
    Authenticate and log in a user.

    Parameters
    ----------
    request : HttpRequest
        Incoming HTTP request.

    Returns
    -------
    HttpResponse
        Redirects to home if successful or shows error page.
    """
    if request.method == "POST":

        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect("home")

        else:
            return render(request, "error.html", {
                "error": "Invalid credentials"
            })

    return render(request, "login.html")
#------------------------------------------------------------------[Home]------------------------------------------------------------------#
    
def home(request):
    """
    Render the homepage of the application.

    Returns
    -------
    HttpResponse
        Rendered home template.
    """
#------------------------------------------------------------------End of home------------------------------------------------------------------#
    return render(request, "home.html")


                                                      #####------------Reset password -------------#####
@login_required                                                
def resetpage(request):
    """
    Display password reset page for authenticated users.
    """
    if request.method == 'POST':
        return render(request, 'reset.html')
    return render(request, 'reset.html')

@login_required
def reset_password(request):
    """
    Update the user's password.

    Validates the old password before saving the new password and
    keeps the user logged in after the update.

    Returns
    -------
    HttpResponse
        Confirmation or error message page.
    """
    if request.method == 'POST':
        old_password = request.POST.get('old_password')
        new_password = request.POST.get('new_password')

        user = request.user

        if not user.check_password(old_password):
            return render(request, "reset.html", {
                'incorrect_password': "Incorrect password, enter again"
            })

        user.set_password(new_password)
        user.save()

        update_session_auth_hash(request, user)

        return render(request, "registration.html", {
            'password_update': "Password updated"
        })

    return render(request, "reset.html")
         
    #------------------------------------------------------------------End of login and registration------------------------------------------------------------------#
   
      
      #------------------------------------------------------------------[Sellers]------------------------------------------------------------------#
    
def sellerpage(request):
    """
    Render the seller dashboard page.
    """
    return render(request, "seller.html")   
                                                         #####------------Create a store-------------#####
                 
#1. Add sellers only authentication
@login_required
def create_store(request):
    """
    Create a new store for the authenticated user.

    Also posts a tweet announcing the store.

    Parameters
    ----------
    request : HttpRequest
        Incoming HTTP request.

    Returns
    -------
    HttpResponseRedirect
        Redirects to home after store creation.
    """
    if request.method == "POST":
        store_name = request.POST.get("store_name")

        store = Store.objects.create(
            store=store_name,
            owner=request.user
        )

        tweet = Tweet()

        tweet.make_tweet(
            f"New store launched!\n\nStore: {store.store} \nDescription: {store.owner} "
        )

        return redirect("home")

    return render(request, "create_store.html")
                                                 #####------------View store-------------#####

@login_required
def view_store(request, store_id):
    """"
    Display details of a specific store.

    Parameters
    ----------
    request : HttpRequest
        Incoming request.
    store_id : int
        Store identifier.

    Returns
    -------
    HttpResponse
        Rendered store page.
    """
    store = get_object_or_404(Store, id=store_id)
    return render(request, "seller.html", {"store": store})
                                                #####------------View products-------------#####


@login_required
def view_products(request):
    """
    Display all products available to sellers.
    """
    products = Product.objects.all()
    return render(request, "seller.html", {"products": products})

                                                #####------------Edit or delete store-------------#####


@login_required
def remove_store(request, store_id):
    """
    Delete a store owned by the current user.

    Parameters
    ----------
    store_id : int
        Store identifier.
    """
    store = get_object_or_404(Store, id=store_id, owner=request.user)
    store.delete()
    return redirect("seller")


@login_required
def edit_store(request, store_id):
    """
    Edit store information and related product data.
    """
    store = get_object_or_404(Store, id=store_id, owner=request.user)

    if request.method == "POST":
        store_name = request.POST.get("store_name")
        product_quantities = request.POST.get("quantities")
        product_description = request.POST.get("product_description")
        product_price = request.POST.get("price")
        product_name = request.POST.get("product")

        store.store = store_name
        store.name = product_name
        store.quantities = product_quantities
        store.description = product_description
        store.price = product_price
        store.save()

        return redirect("store_detail", store_id=store.id)

    return render(request, "seller.html", {"store": store})
    
    #------------------------------------------------------------------End of Sellers------------------------------------------------------------------#


        #------------------------------------------------------------------[Buyers]------------------------------------------------------------------#

def buyerpage(request):
    """
    Render the buyer dashboard page.
    """
    return render(request, "buyer.html")     
                                                 #####------------View Products -------------#####
def buyer_products(request):
    """
    Display all available products to buyers.
    """
    products = Product.objects.all()
    return render(request, "buyer.html", {"products": products})

                                                #####------------View and add to cart -------------#####
def cartpage(request):
    """
    Render the shopping cart page.
    """
    return render(request, "buyer.html")
     
def add_to_cart(request, product_id):
    """
    Add a product to the session-based shopping cart.

    Parameters
    ----------
    product_id : int
        ID of the product being added.
    """
    cart = request.session.get("cart", {})
    cart[str(product_id)] = cart.get(str(product_id), 0) + 1
    request.session["cart"] = cart
    return redirect("product_list")

def view_cart(request):
    """
    Display products currently stored in the user's cart.
    """
    cart = request.session.get("cart", {})
    products = Product.objects.filter(id__in=cart.keys())

    return render(request, "cart.html", {
        "products": products,
        "cart": cart
    })
                                          
                                                #####------------Checkouts -------------#####
def checkoutpage(request):
    """
    Process checkout and generate invoice.

    Creates order records, generates an invoice file,
    and emails it to the user.

    Parameters
    ----------
    request : HttpRequest
        Incoming request.

    Returns
    -------
    HttpResponseRedirect
        Redirects to buyer page after checkout.
    """
    return render(request, "checkout.html")
     
    
def checkout(request):
    """
    Process the user's checkout.

    Creates order records, generates an invoice file, and emails the
    invoice to the user.
    """
    cart = request.session.get("cart", {})

    orders = []

    for product_id, quantity in cart.items():
        product = Product.objects.get(id=product_id)

        order = Order.objects.create(
            buyer=request.user,
            product=product,
            quantity=quantity
        )

        orders.append(order)

    invoice_content = f"Invoice for {request.user.username}\n\n"

    for order in orders:
        invoice_content += (
            f"Product: {order.product.name}\n"
            f"Quantity: {order.quantity}\n\n"
        )

    with open("invoice.txt", "w") as invoice:
        invoice.write(invoice_content)

    subject = f"{request.user.username.upper()}, your order invoice"
    body = f"Hi {request.user.username},\n\nPlease find your invoice attached."
    sender = "skrubbieorders@co.za"
    recipient = [request.user.email]

    email = EmailMessage(subject, body, sender, recipient)
    email.attach_file("invoice.txt")
    email.send()

    request.session["cart"] = {}

    return redirect("buyer")

                                    #####------------Leave review -------------#####

def leave_review(request, product_id):
    """
    Allow buyers to leave product reviews.

    Reviews are marked as verified if the user has previously purchased
    the product.
    """

    if request.user.profile.user_type != "buyer":
        return HttpResponseForbidden("Only buyers can leave reviews.")

    product = get_object_or_404(Product, id=product_id)

    if request.method == "POST":
        content = request.POST.get("content")

        has_purchased = Order.objects.filter(
            buyer=request.user,
            product=product
        ).exists()

        Review.objects.create(
            product=product,
            user=request.user,
            content=content,
            verified=has_purchased
        )

        return redirect("buyer")
    products = Product.objects.all()
    reviews = Review.objects.all()
    return render(
        request,
        "buyer.html",
        {
            "products": products,
            "reviews": reviews
        }
    )

    #------------------------------------------------------------------End of Buyers------------------------------------------------------------------#
    #------------------------------------------------------------------[API]------------------------------------------------------------------#
    

class StoreViewSet(viewsets.ModelViewSet):
    """
    API endpoint for managing stores.

    Provides create, read, update, and delete operations.
    """

    queryset = Store.objects.all()
    serializer_class = StoreSerializer


class ProductViewSet(viewsets.ModelViewSet):
    """
    API endpoint providing CRUD operations for products.
    """
    queryset = Product.objects.all()
    serializer_class = ProductSerializer


class ReviewViewSet(viewsets.ModelViewSet):
    """
    API endpoint providing CRUD operations for product reviews.
    """
    queryset = Review.objects.all()
    serializer_class = ReviewSerializer
        
 #------------------------------------------------------------------End of API------------------------------------------------------------------#
