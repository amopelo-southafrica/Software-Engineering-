from rest_framework.permissions import BasePermission


class IsSeller(BasePermission):
    """
    Allows access only to users with seller role.
    """

    def has_permission(self, request, view):
        return (
            request.user.is_authenticated and
            hasattr(request.user, 'profile') and
            request.profile.user_type == "seller"
        )


class IsOwner(BasePermission):
    """
    Object-level permission to allow only owners to edit.
    """

    def has_object_permission(self, request, view, obj):
        return obj.owner == request.user