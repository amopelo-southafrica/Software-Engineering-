import json
from requests_oauthlib import OAuth1Session


class Tweet:

    _instance = None

    CONSUMER_KEY = "mfEvvPGDZAAlF0Fv7x74bde9d"
    CONSUMER_SECRET = "NpHhHV0Gws1gGFMhebPxZRcj4bKwyAX1UMLa5854TN6ODc6ZRv"

    ACCESS_TOKEN = "2029540328395718656-uTJDl1YXtfxjQ37tirFOfOO7vkuvrP"
    ACCESS_TOKEN_SECRET = "xABk7Q6vfUCOkdEF3QOi9MoSiNYF2CkvvJvte2oqNxVvJ"

    def __new__(cls):

        if cls._instance is None:

            cls._instance = super(Tweet, cls).__new__(cls)
            cls._instance.oauth = None
            cls._instance.authenticate()

        return cls._instance


    def authenticate(self):

        self.oauth = OAuth1Session(
            self.CONSUMER_KEY,
            client_secret=self.CONSUMER_SECRET,
            resource_owner_key=self.ACCESS_TOKEN,
            resource_owner_secret=self.ACCESS_TOKEN_SECRET
        )

        print("Twitter authentication successful")


    def make_tweet(self, tweet):

        response = self.oauth.post(
            "https://api.twitter.com/1.1/statuses/update.json",
            data={"status": tweet}
        )

        if response.status_code != 200:

            raise Exception(
                f"Tweet failed: {response.status_code} — {response.text}"
            )

        print("Tweet posted successfully")

        json_response = response.json()

        print(json.dumps(json_response, indent=4))