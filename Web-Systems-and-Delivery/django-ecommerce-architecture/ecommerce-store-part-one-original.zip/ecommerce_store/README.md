E-Commerce Django Platform
1. Overview

This project is a Django-based e-commerce platform that allows users to register as buyers or sellers, create stores, manage products, place orders, and leave reviews. The system also includes user authentication, session-based cart management, and REST API endpoints for key resources.

2. Features
2.1 User Management

User registration and login

Role-based access (Buyer and Seller)

Password reset functionality

2.2 Seller Functionality

Create and manage stores

Add and manage products

View store details and product listings

2.3 Buyer Functionality

Browse available products

Add products to a session-based cart

Checkout and generate orders

Receive invoice via email

2.4 Reviews

Buyers can leave reviews on products

Reviews are marked as verified if the product was purchased

2.5 API Support

REST API endpoints for:

Stores

Products

Reviews

3. System Architecture

The application follows Django’s Model-View-Template (MVT) architecture:

Models: Define the database structure and relationships (e.g., Profile, Store, Product, Order, Review)

Views: Handle business logic and HTTP request processing

Templates: Render the user interface

Serializers: Convert model data for API usage

4. HTTP State Management

HTTP is a stateless protocol, meaning each request is processed independently. This application maintains user state using Django sessions. When a user logs in, a session is created and stored on the server, while a session ID is stored in the browser. This allows the system to recognize the user across multiple requests.

The shopping cart functionality is implemented using session storage, where selected products are stored in the session object. This ensures that cart data persists across different pages without requiring a database write for each interaction.

5. Database Configuration and Migration
5.1 Initial Setup (SQLite)

The application was initially configured to use SQLite, a lightweight, file-based database integrated with Django. SQLite is suitable for development due to its simplicity and minimal setup requirements.

5.2 Migration to MariaDB

To improve scalability and support multiple users, the database was migrated to MariaDB, a server-based relational database system.

Steps followed:

Install MariaDB Server and create a database and user:

CREATE DATABASE ecommerce_db;
CREATE USER 'ecom_user'@'localhost' IDENTIFIED BY 'password';
GRANT ALL PRIVILEGES ON ecommerce_db.* TO 'ecom_user'@'localhost';
FLUSH PRIVILEGES;

Install a database connector:

pip install pymysql

Configure Django database settings:

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'ecommerce_db',
        'USER': 'ecom_user',
        'PASSWORD': 'password',
        'HOST': 'localhost',
        'PORT': '3306',
    }
}

Enable PyMySQL in the project:

import pymysql
pymysql.install_as_MySQLdb()

Apply migrations:

python manage.py makemigrations
python manage.py migrate

Optional data transfer:

python manage.py dumpdata > data.json
python manage.py loaddata data.json
5.3 Outcome

After migration, the application successfully operated using MariaDB. All functionalities remained unchanged due to Django’s ORM abstraction. The system is now capable of handling multiple users and concurrent operations more efficiently.

6. Installation and Setup
6.1 Clone the Repository
git clone <repository-url>
cd ecommerce_store
6.2 Create Virtual Environment
python -m venv venv
venv\Scripts\activate
6.3 Install Dependencies
pip install -r requirements.txt
6.4 Apply Migrations
python manage.py migrate
6.5 Run the Application
python manage.py runserver
7. Project Structure
ecommerce_store/
│
├── ecommerce/
│   ├── models.py
│   ├── views.py
│   ├── serializers.py
│   ├── permissions.py
│   ├── urls.py
│
├── manage.py
├── settings.py
8. Limitations

SQLite is not suitable for production use

No payment gateway integration

Basic user interface

Limited validation and error handling in some areas

9. Future Improvements

Integration of payment systems (e.g., Stripe or PayPal)

Improved database optimization and indexing

Enhanced UI/UX design

Implementation of token-based authentication (JWT)

Deployment to a cloud platform

10. Conclusion

This project demonstrates the development of a functional e-commerce system using Django, incorporating user authentication, session management, API integration, and database migration. The transition from SQLite to MariaDB enhances scalability and prepares the application for real-world deployment.

